from __future__ import annotations

from typing import Optional

from matplotlib.pyplot import sca
import numpy as np
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from tf.transformations import euler_from_quaternion

from gazebo_rl_gym.envs.base.robot_spec import RobotEnvSpec


class Turtlebot3Spec(RobotEnvSpec):
    """Concrete TurtleBot3 spec with diff-drive control and lidar sensing."""

    POSE_KEYS: tuple[str, ...] = ("x", "y", "yaw","vx", "vy", "wz")
    REWARD_POSITION_KEYS: tuple[str, ...] = ("x", "y")
    SCAN_DIM: int = 360

    def __init__(self, name: str, cfg):
        super().__init__(name, cfg)
        self._current_height: float = 0.0
        self._last_scan_min_value: Optional[float] = None

    def reset(self) -> None:
        super().reset()
        self._current_height = 0.0
        self._last_scan_min_value = None

    @property
    def observation_dim(self) -> int:
        """
        Return the dimension of the observation vector produced by this spec.
        """
        dim = len(self.POSE_KEYS) + self.SCAN_DIM
        return dim

    @property
    def uses_scan(self) -> bool:
        return self.SCAN_DIM > 0 and bool(super().uses_scan)

    def build_observation(self, pose_msg: Odometry, scan_msg: Optional[LaserScan]) -> np.ndarray:
        translation = pose_msg.pose.pose.position
        rotation = pose_msg.pose.pose.orientation
        roll, pitch, yaw = euler_from_quaternion([rotation.x, rotation.y, rotation.z, rotation.w])

        mapping = {
            "x": translation.x,
            "y": translation.y,
            "z": translation.z,
            "roll": roll,
            "pitch": pitch,
            "yaw": yaw,
            "vx": pose_msg.twist.twist.linear.x,
            "vy": pose_msg.twist.twist.linear.y,
            "vz": pose_msg.twist.twist.linear.z,
            "wx": pose_msg.twist.twist.angular.x,
            "wy": pose_msg.twist.twist.angular.y,
            "wz": pose_msg.twist.twist.angular.z,
        }
        components: list[float] = []
        for key in self.POSE_KEYS:
            components.append(mapping[key])
        pose_vec = np.array(components, dtype=np.float32) 

        self._last_scan_min_value = None 
        scan = np.array(scan_msg.ranges, dtype=np.float32)
        scan = np.nan_to_num(scan, nan=scan_msg.range_max, posinf=scan_msg.range_max, neginf=0.0)

        if scan.size > self.SCAN_DIM:
            scan = scan[:self.SCAN_DIM]

        if self.cfg.observation.normalize_scan and scan_msg.range_max > 0:
            scan /= scan_msg.range_max

        self._last_scan_min_value = float(np.min(scan))
        self._current_height = float(translation.z)

        parts = [vec for vec in (pose_vec, scan) if vec.size]
        return np.concatenate(parts)
    
    def compute_reward(self) -> float:
        reward=0
        # 获取当前和前一时刻的观测值
        curr = self.current_observation
        prev = self.previous_observation
        # 获取姿态维度
        pose_dim = len(self.POSE_KEYS)
        # 提取当前和前一时刻的姿态部分
        curr_pose = curr[:pose_dim]
        prev_pose = prev[:pose_dim]
        # 创建姿态组件到索引的映射
        indices = {comp: idx for idx, comp in enumerate(self.POSE_KEYS)}
        # 计算奖励位置键的增量
        deltas = []
        for comp in self.REWARD_POSITION_KEYS:
            idx = indices.get(comp)
            if idx is not None:
                deltas.append(curr_pose[idx] - prev_pose[idx])
        # 计算距离奖励，使用距离缩放因子
        distance_scale = getattr(self.cfg.reward, "distance_scale", 1.0)
        reward += float(np.linalg.norm(deltas) * distance_scale) if deltas else 0.0
        # 计算动作平滑惩罚
        smooth_scale = getattr(self.cfg.reward, "smoothness_scale", 0.0)
        if smooth_scale > 0.0:
            diff = self.current_action - self.previous_action
            reward -= float(smooth_scale * np.dot(diff, diff))
        # 计算碰撞惩罚
        collision_penalty = getattr(self.cfg.reward, "collision_penalty", 0.0)
        if collision_penalty > 0.0 and self.collision_active:
            reward -= float(collision_penalty)
        # 计算最小范围惩罚（基于激光扫描）
        min_range_penalty = getattr(self.cfg.reward, "min_range_penalty", 0.0)
        min_range_threshold = getattr(self.cfg.reward, "min_range_threshold", 0.0)
        shortfall = max(0.0, min_range_threshold - self._last_scan_min_value)
        if shortfall > 0.0:
            reward -= float(min_range_penalty * (shortfall / min_range_threshold))
        return reward

    def is_done(self) -> bool:
        if getattr(self.cfg.termination, "collision", False) and self.collision_active:
            return True
        min_height = getattr(self.cfg.termination, "min_height", None)
        if min_height is None:
            return False
        return bool(self._current_height < float(min_height))

    def command_from_action(self, action: np.ndarray) -> Twist:
        twist = Twist()
        twist.linear.x = float(np.clip(action[0], self.action_low[0], self.action_high[0]))
        twist.angular.z = float(np.clip(action[1], self.action_low[1], self.action_high[1]))
        return twist

