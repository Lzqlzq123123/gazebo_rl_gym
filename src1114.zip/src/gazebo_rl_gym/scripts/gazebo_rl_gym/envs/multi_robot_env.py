import gym
import rospy
import roslaunch
import numpy as np
import os
import time
import threading
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_srvs.srv import Empty
from gazebo_msgs.srv import SetModelState, GetModelState
from gazebo_msgs.msg import ModelState, ContactsState
from tf.transformations import quaternion_from_euler
from rosgraph_msgs.msg import Clock

from gazebo_rl_gym.utils.config_loader import load_environment_config
from gazebo_rl_gym.utils.path_utils import resolve_relative

class MultiRobotGazeboEnv(gym.Env):
    def __init__(self, config_path: str | None = None):
        super(MultiRobotGazeboEnv, self).__init__()

        if config_path is None:
            return
        self.config_path = os.path.abspath(config_path)

        # Load environment configuration including robots lisy 
        self.env_config = load_environment_config(self.config_path)

        # Extract robot configurations and specifications in env_config
        self.robot_configs = self.env_config.robots
        self.scenarios = {robot.name: robot for robot in self.robot_configs}
        self.specs = {name: scenario.spec for name, scenario in self.scenarios.items()}
        self.robot_names = list(self.scenarios.keys())

        if not self.robot_names:
            raise ValueError(f"No robots defined in configuration '{self.config_path}'")

        # Launch Gazebo simulation with specified world and robots
        self._launch_gazebo()

        rospy.init_node('gazebo_gym_env', anonymous=True)

        self._physics_paused = False
        self.sim_time = None
        self._clock_event = threading.Event()
        rospy.Subscriber('/clock', Clock, self._clock_callback)

        self.observation_sizes = {
            name: spec.observation_dim for name, spec in self.specs.items()
        }
        self.action_sizes = {
            name: spec.action_dim for name, spec in self.specs.items()
        }

        print("@@@@@@@@@@@@@@@@@@@@@@@@@@", self.observation_sizes)
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@", self.action_sizes)
        for name, size in self.observation_sizes.items():
            if size is None or size <= 0:
                raise ValueError(f"Observation dimension must be positive for robot '{name}'")
        for name, size in self.action_sizes.items():
            if size is None or size <= 0:
                raise ValueError(f"Action dimension must be positive for robot '{name}'")

        
        self.observation_space = gym.spaces.Dict({
            name: gym.spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(self.observation_sizes[name],),
                dtype=np.float32,
            )
            for name in self.robot_names
        })
        self.action_space = gym.spaces.Dict({
            name: gym.spaces.Box(
                low=self.specs[name].action_low,
                high=self.specs[name].action_high,
                dtype=np.float32,
            )
            for name in self.robot_names
        })

        # Determine if all robots have the same observation dimension
        self.obs_dim = next(iter(self.observation_sizes.values()))
        if not all(dim == self.obs_dim for dim in self.observation_sizes.values()):
            self.obs_dim = None

        self.action_dim = next(iter(self.action_sizes.values()))
        if not all(dim == self.action_dim for dim in self.action_sizes.values()):
            self.action_dim = None

        self.action_pubs = {}
        self.scan_buffer = {name: None for name in self.robot_names}
        self.pose_buffer = {name: None for name in self.robot_names}
        self.scan_stamps = {name: None for name in self.robot_names}
        self.pose_stamps = {name: None for name in self.robot_names}
        self.scan_topics = {}
        self.pose_topics = {}
        self.contact_topics = {}
        self.contact_buffer = {name: False for name in self.robot_names}

        for name in self.robot_names:
            spec = self.specs[name]
            self.action_pubs[name] = rospy.Publisher(spec.cmd_topic, Twist, queue_size=1)
            pose_topic = spec.pose_topic
            self.pose_topics[name] = pose_topic
            rospy.loginfo(f"Subscribing robot {name} to pose: {pose_topic}")
            rospy.Subscriber(pose_topic, Odometry, self._pose_callback, callback_args=name)

            if spec.uses_scan:
                scan_topic = spec.scan_topic
                self.scan_topics[name] = scan_topic
                rospy.loginfo(f"Subscribing robot {name} to scan: {scan_topic}")
                rospy.Subscriber(scan_topic, LaserScan, self._scan_callback, callback_args=name)
            else:
                self.scan_topics[name] = None

            if spec.uses_contact:
                contact_topic = spec.contact_topic
                self.contact_topics[name] = contact_topic
                rospy.loginfo(f"Subscribing robot {name} to contacts: {contact_topic}")
                rospy.Subscriber(contact_topic, ContactsState, self._contact_callback, callback_args=name)
            else:
                self.contact_topics[name] = None

        rospy.loginfo(
            "Configured robots: %s",
            ", ".join(f"{name} ({self.specs[name].cfg.model})" for name in self.robot_names),
        )

        metadata = self.env_config.metadata or {}
        self.topic_timeout = float(metadata.get("topic_timeout", 2.0))
        self.sim_wait_timeout = float(metadata.get("sim_wait_timeout", max(self.topic_timeout, 3.0)))
        self.min_sim_dt = float(metadata.get("min_sim_dt", 0.01))
        self.model_wait_timeout = float(metadata.get("model_wait_timeout", 15.0))
        if self.sim_wait_timeout <= 0:
            raise ValueError("sim_wait_timeout must be positive")
        if self.min_sim_dt <= 0:
            raise ValueError("min_sim_dt must be positive")
        if self.model_wait_timeout <= 0:
            raise ValueError("model_wait_timeout must be positive")
        self.unpause = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        self.pause = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
        self.reset_world = rospy.ServiceProxy('/gazebo/reset_world', Empty)
        self.reset_simulation = rospy.ServiceProxy('/gazebo/reset_simulation', Empty)
        self.set_model_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
        self.get_model_state = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)

        # rospy.wait_for_service('/gazebo/get_model_state')

        rospy.loginfo("Environment communication initialized. Sensors will sync on reset().")

    def _clock_callback(self, msg: Clock) -> None:
        self.sim_time = msg.clock.to_sec()
        self._clock_event.set()

    def _pause_physics(self, *, force: bool = False) -> None:
        if self._physics_paused and not force:
            return

        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause()
        except rospy.ServiceException as exc:
            rospy.logerr("pause_physics service call failed: %s", exc)
            raise

        self._physics_paused = True

    def _unpause_physics(self, *, force: bool = False) -> None:
        if not self._physics_paused and not force:
            return

        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause()
        except rospy.ServiceException as exc:
            rospy.logerr("unpause_physics service call failed: %s", exc)
            raise

        self._physics_paused = False

    def _capture_sensor_stamps(self) -> tuple[dict[str, float | None], dict[str, float | None]]:
        scan_stamps = {name: self.scan_stamps.get(name) for name in self.robot_names}
        pose_stamps = {name: self.pose_stamps.get(name) for name in self.robot_names}
        return scan_stamps, pose_stamps

    def _clear_sensor_buffers(self) -> None:
        for name in self.robot_names:
            self.scan_buffer[name] = None
            self.pose_buffer[name] = None
            self.scan_stamps[name] = None
            self.pose_stamps[name] = None
            self.contact_buffer[name] = False
            self.specs[name].reset()
            if self.specs[name].uses_contact:
                self.specs[name].update_contact_state(None)

    def _wait_for_models(self, timeout: float | None = None) -> None:
        wait_timeout = timeout if timeout is not None else self.model_wait_timeout
        if wait_timeout <= 0:
            return

        pending = set(self.robot_names)
        deadline = time.time() + wait_timeout
        last_log = 0.0

        while pending and time.time() < deadline:
            for name in list(pending):
                try:
                    response = self.get_model_state(name, "")
                except rospy.ServiceException as exc:
                    rospy.logdebug("get_model_state for %s failed: %s", name, exc)
                    continue

                if response.success:
                    pending.remove(name)

            if pending:
                now = time.time()
                if now - last_log > 1.0:
                    rospy.loginfo(
                        "Waiting for models to spawn: %s",
                        ", ".join(sorted(pending)),
                    )
                    last_log = now
                time.sleep(0.1)

        if pending:
            missing = ", ".join(sorted(pending))
            raise RuntimeError(
                f"Timed out waiting for models to spawn: {missing}. check spawner logs."
            )

        rospy.loginfo("Detected models in Gazebo: %s", ", ".join(sorted(self.robot_names)))

    def _advance_simulation(
        self,
        *,
        min_dt: float,
        timeout: float,
        require_fresh_sensors: bool = False,
        prev_scan_stamps: dict[str, float | None] | None = None,
        prev_pose_stamps: dict[str, float | None] | None = None,
    ) -> None:
        """Unpause Gazebo, wait for the clock/sensors to advance, then pause again."""
        if prev_scan_stamps is None:
            prev_scan_stamps = {}
        if prev_pose_stamps is None:
            prev_pose_stamps = {}

        start_sim_time = self.sim_time
        deadline = time.time() + timeout

        self._unpause_physics(force=True) #强制让 Gazebo 开始运行物理仿真

        try:
            while time.time() < deadline:
                current_sim_time = self.sim_time
                if start_sim_time is None and current_sim_time is not None:
                    start_sim_time = current_sim_time

                sim_ready = (
                    current_sim_time is not None
                    and start_sim_time is not None
                    and current_sim_time >= start_sim_time + min_dt - 1e-9
                )

                # 检查传感器数据是否更新
                sensors_ready = True
                if require_fresh_sensors:
                    sensors_ready = False
                    all_ready = True
                    for name in self.robot_names:
                        spec = self.specs[name]
                        scan_stamp = self.scan_stamps.get(name)
                        pose_stamp = self.pose_stamps.get(name)
                        prev_scan = prev_scan_stamps.get(name)
                        prev_pose = prev_pose_stamps.get(name)

                        if pose_stamp is None:
                            all_ready = False
                            break

                        if prev_pose is not None and pose_stamp <= prev_pose:
                            all_ready = False
                            break

                        if spec.uses_scan:
                            if scan_stamp is None:
                                all_ready = False
                                break
                            if prev_scan is not None and scan_stamp <= prev_scan:
                                all_ready = False
                                break

                    sensors_ready = all_ready

                if sim_ready and sensors_ready:
                    return

                time.sleep(0.001)

            current_sim_time = self.sim_time
            sensor_details: list[str] = []
            if require_fresh_sensors:
                for name in self.robot_names:
                    spec = self.specs[name]
                    scan_stamp = self.scan_stamps.get(name)
                    pose_stamp = self.pose_stamps.get(name)
                    prev_scan = prev_scan_stamps.get(name)
                    prev_pose = prev_pose_stamps.get(name)

                    if pose_stamp is None:
                        sensor_details.append(f"{name}:pose-missing")
                    elif prev_pose is not None and pose_stamp <= prev_pose:
                        sensor_details.append(f"{name}:pose-stale")

                    if spec.uses_scan:
                        if scan_stamp is None:
                            sensor_details.append(f"{name}:scan-missing")
                        elif prev_scan is not None and scan_stamp <= prev_scan:
                            sensor_details.append(f"{name}:scan-stale")

            rospy.logerr(
                "Timed out waiting for simulation advance (Δt>=%.3fs). Last clock=%.6f. Sensor status: %s",
                min_dt,
                current_sim_time if current_sim_time is not None else float('nan'),
                ", ".join(sensor_details) if sensor_details else "n/a",
            )

            raise RuntimeError(
                "Timed out waiting for simulation advance; ensure Gazebo clock and sensors are publishing"
            )
        finally:
            self._pause_physics(force=True)

    def _scan_callback(self, msg: LaserScan, robot_name: str) -> None:
        self.scan_buffer[robot_name] = msg
        stamp = msg.header.stamp.to_sec() if msg.header.stamp else rospy.Time.now().to_sec()
        self.scan_stamps[robot_name] = stamp
        rospy.logdebug(f"Received scan for {robot_name}: {len(msg.ranges)} ranges")

    def _pose_callback(self, msg: Odometry, robot_name: str) -> None:
        self.pose_buffer[robot_name] = msg
        stamp = msg.header.stamp.to_sec() if msg.header.stamp else rospy.Time.now().to_sec()
        self.pose_stamps[robot_name] = stamp
        rospy.logdebug(f"Received pose for {robot_name}: x={msg.pose.pose.position.x:.2f}, y={msg.pose.pose.position.y:.2f}")

    def _contact_callback(self, msg: ContactsState, robot_name: str) -> None:
        collision = bool(msg.states)
        self.contact_buffer[robot_name] = collision
        spec = self.specs.get(robot_name)
        if spec is not None:
            spec.update_contact_state(msg)
        if collision:
            rospy.logdebug(f"Collision detected for {robot_name} with {len(msg.states)} contact(s)")

    def step(self, actions):
        # Pause first to apply actions deterministically
        self._pause_physics()

        prev_scan_stamps, prev_pose_stamps = self._capture_sensor_stamps()

        for name, action in actions.items():
            spec = self.specs[name]
            action_vec = np.asarray(action, dtype=np.float32)
            twist = spec.apply_action(action_vec)
            self.action_pubs[name].publish(twist)

        # 检查数据是否更新
        self._advance_simulation(
            min_dt=self.min_sim_dt,
            timeout=self.sim_wait_timeout,
            require_fresh_sensors=True,
            prev_scan_stamps=prev_scan_stamps,
            prev_pose_stamps=prev_pose_stamps,
        )

        obs = self._get_observations()
        rewards = {name: self.specs[name].compute_reward() for name in self.robot_names}
        dones = {name: self.specs[name].is_done() for name in self.robot_names}
        # 整体done标志，所有机器人都done才算done
        dones["__all__"] = all(dones.values())

        return obs, rewards, dones, {}

    def reset(self):
        self._pause_physics(force=True)

        rospy.wait_for_service('/gazebo/reset_world')
        try:
            self.reset_world()
        except rospy.ServiceException as exc:
            rospy.logwarn("reset_world service call failed: %s", exc)
            rospy.logwarn("Falling back to reset_simulation")
            rospy.wait_for_service('/gazebo/reset_simulation')
            try:
                self.reset_simulation()
            except rospy.ServiceException as exc_sim:
                rospy.logerr("reset_simulation service call failed: %s", exc_sim)
                raise
        # 重置内部时间戳缓存
        self.sim_time = None
        self._clock_event.clear()

        # Reset robot positions based on config
        self._wait_for_models()
        for robot_cfg in self.robot_configs:
            self._reset_robot_pose(robot_cfg)

        self._clear_sensor_buffers()

        #检查数据是否存在且不为 None
        self._advance_simulation(
            min_dt=self.min_sim_dt,
            timeout=self.sim_wait_timeout,
            require_fresh_sensors=True,
            prev_scan_stamps={},  # Empty dict means no previous stamps to compare
            prev_pose_stamps={},  # Empty dict means no previous stamps to compare
        )

        return self._get_observations()

    def _reset_robot_pose(self, robot_config):
        state_msg = ModelState()
        state_msg.model_name = robot_config.name

        pose = robot_config.pose
        state_msg.pose.position.x = pose.get('x', 0.0)
        state_msg.pose.position.y = pose.get('y', 0.0)
        state_msg.pose.position.z = pose.get('z', 0.0)
        q = quaternion_from_euler(0, 0, pose.get('yaw', 0.0))
        state_msg.pose.orientation.x = q[0]
        state_msg.pose.orientation.y = q[1]
        state_msg.pose.orientation.z = q[2]
        state_msg.pose.orientation.w = q[3]

        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.set_model_state(state_msg)
        except rospy.ServiceException as e:
            print("set_model_state service call failed: %s" % e)


    def _get_observations(self):
        # 初始化观测字典
        obs_dict = {}
        # 遍历每个机器人，收集其观测数据
        for name in self.robot_names:
            spec = self.specs[name]

            # 如果姿态或扫描数据缺失，等待数据到达
            if self.pose_buffer[name] is None or (spec.uses_scan and self.scan_buffer[name] is None):
                rospy.logwarn(f"Waiting for initial sensor data for {name}")
                start = time.time()
                while self.pose_buffer[name] is None or (spec.uses_scan and self.scan_buffer[name] is None):
                    # 检查是否超时
                    if time.time() - start > self.topic_timeout:
                        missing = []
                        if self.pose_buffer[name] is None:
                            missing.append("pose")
                        if spec.uses_scan and self.scan_buffer[name] is None:
                            missing.append("scan")
                        rospy.logerr(f"Missing {missing} for {name} after {self.topic_timeout}s")
                        raise RuntimeError(f"Timed out waiting for observation data for robot {name}")
                    time.sleep(0.01)

            # 获取姿态和扫描消息
            pose_msg = self.pose_buffer[name]
            scan_msg = self.scan_buffer[name] if spec.uses_scan else None
            # 调用每个机器人的数据处理函数，处理传感器数据并存储到观测字典中
            obs_dict[name] = spec.process_sensor_data(pose_msg, scan_msg)

        return obs_dict

    def _launch_gazebo(self):
        uuid = roslaunch.rlutil.get_or_generate_uuid(None, False)
        roslaunch.configure_logging(uuid)
        
        launch_file = resolve_relative('launch', 'multi_robot.launch')
        
        # roslaunch参数必须是字符串列表格式: ['arg:=value']
        launch_args = [
            f'config_file:={self.config_path}',
            f'world_file:={self.env_config.world_file}',
        ]
        
        print(f"Launch args: {launch_args}")
        print(f"World file: {self.env_config.world_file}")

        self.launch = roslaunch.parent.ROSLaunchParent(uuid, [(launch_file, launch_args)])
        self.launch.start()
        print("Gazebo launched")

    def get_observation_size(self, robot_name: str) -> int:
        return self.observation_sizes[robot_name]

    def get_action_size(self, robot_name: str) -> int:
        return self.action_sizes[robot_name]

    def close(self):
        if hasattr(self, 'launch'):
            self.launch.shutdown()
        
if __name__ == '__main__':
    # For testing
    env = MultiRobotGazeboEnv()
    obs = env.reset()
    print("Reset successful. Initial observations:", obs)
    for _ in range(10):
        actions = {name: env.action_space[name].sample() for name in env.robot_names}
        obs, rewards, dones, _ = env.step(actions)
        print("Step successful. Rewards:", rewards)
        if dones["__all__"]:
            print("Episode finished.")
            obs = env.reset()
    env.close()
