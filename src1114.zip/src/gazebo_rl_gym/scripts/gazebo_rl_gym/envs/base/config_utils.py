import collections.abc


def update_config_from_dict(cfg, overrides):
    """Recursively update a config object using a dictionary."""
    for key, value in overrides.items():
        if not hasattr(cfg, key):
            continue
        attr = getattr(cfg, key)
        if isinstance(value, collections.abc.Mapping) and not isinstance(attr, (int, float, str, bool, list, tuple, set, type(None))):
            update_config_from_dict(attr, value)
        else:
            setattr(cfg, key, value)
