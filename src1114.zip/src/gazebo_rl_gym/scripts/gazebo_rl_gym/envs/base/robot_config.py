from typing import List

from .base_config import BaseConfig


class RobotCfg(BaseConfig):
    """机器人配置类，定义机器人的基本参数、话题、观测、动作空间、奖励和终止条件。"""

    # 机器人模型名称
    model: str = ""
    # 控制器类型
    controller_type: str = ""
    # 机器人基座坐标系模板，使用 {name} 占位符
    base_frame: str = "{name}/base_link"
    # 地图坐标系
    map_frame: str = "map"

    class topics:
        """定义机器人相关的话题名称。"""
        # 速度命令话题
        cmd = "/{name}/cmd_vel"
        # 姿态话题
        pose = "/{name}/ground_truth/state"
        # 激光扫描话题
        scan = "/{name}/scan"
        # 接触状态话题
        contact = "/{name}/contact_states"

    class observation:
        """观测配置。"""
        # 是否归一化激光扫描数据
        normalize_scan = True
        # 是否在观测中包含碰撞标志
        include_collision_flag = True

    class action_space:
        """动作空间配置。"""
        # 动作下限 [线速度, 角速度]
        low: List[float] = [-0.26, -1.82]
        # 动作上限 [线速度, 角速度]
        high: List[float] = [0.26, 1.82]

    class reward:
        """奖励配置。"""
        # 距离奖励缩放因子
        distance_scale: float = 1.0
        # 动作平滑惩罚缩放因子
        smoothness_scale: float = 0.0
        # 碰撞惩罚值
        collision_penalty: float = 5.0
        # 最小范围惩罚值 用于激光避障
        min_range_penalty: float = 1.5
        # 最小范围阈值 用于激光避障
        min_range_threshold: float = 0.5

    class termination:
        """终止条件配置。"""
        # 最小高度阈值，低于此值终止
        min_height: float = -1.0
        # 是否在碰撞时终止
        collision: bool = True

