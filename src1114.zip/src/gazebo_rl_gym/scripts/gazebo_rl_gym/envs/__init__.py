from .multi_robot_env import MultiRobotGazeboEnv
from .registry import robot_registry
from .turtlebot3.turtlebot3_config import Turtlebot3Cfg
from .turtlebot3.turtlebot3_env import Turtlebot3Spec
from .nanocar.nanocar_config import NanocarCfg
from .nanocar.nanocar_env import NanocarSpec

robot_registry.register("turtlebot3_waffle", Turtlebot3Spec, Turtlebot3Cfg)
robot_registry.register("nanocar", NanocarSpec, NanocarCfg)

__all__ = [
	"MultiRobotGazeboEnv",
	"robot_registry",
	"Turtlebot3Cfg",
	"Turtlebot3Spec",
	"NanocarCfg",
	"NanocarSpec",
]
