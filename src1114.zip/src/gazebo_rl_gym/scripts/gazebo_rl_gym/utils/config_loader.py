"""Helpers for loading and validating multi-robot Gazebo configuration files."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import yaml

from gazebo_rl_gym.envs.registry import robot_registry
from gazebo_rl_gym.utils.path_utils import resolve_relative


@dataclass
class RobotScenario:
    name: str
    preset: str
    pose: Dict[str, float]
    spec: Any


@dataclass
class EnvironmentConfig:
    world_file: str
    robots: List[RobotScenario]
    name: Optional[str] = None
    reward: Dict[str, Any] = field(default_factory=dict)
    termination: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


def _resolve_world_path(world_entry: Optional[str], *, config_dir: Optional[str] = None) -> str:
    default_world = resolve_relative("worlds", "empty.world")
    if not world_entry:
        return default_world

    if os.path.isabs(world_entry):
        return world_entry

    candidates = []
    if config_dir:
        candidates.append(os.path.join(config_dir, world_entry))
    candidates.append(resolve_relative("worlds", world_entry))

    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate

    return world_entry


def _build_robot_overrides(entry: Dict[str, Any]) -> Dict[str, Any]:
    overrides: Dict[str, Any] = {}

    for key in ("model", "controller_type", "base_frame", "map_frame"):
        if key in entry:
            overrides[key] = entry[key]

    if "observation" in entry:
        overrides["observation"] = entry["observation"]
    if "action_space" in entry:
        overrides["action_space"] = entry["action_space"]
    if "reward" in entry:
        overrides["reward"] = entry["reward"]
    if "termination" in entry:
        overrides["termination"] = entry["termination"]

    topics = {}
    if "cmd_topic" in entry:
        topics["cmd"] = entry["cmd_topic"]
    if "pose_topic" in entry:
        topics["pose"] = entry["pose_topic"]
    if "scan_topic" in entry:
        topics["scan"] = entry["scan_topic"]
    if topics:
        overrides["topics"] = topics

    return overrides


def load_environment_config(path: str) -> EnvironmentConfig:
    # Load environment YAML
    with open(path, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)

    config_dir = os.path.dirname(os.path.abspath(path))

    world_entry = raw.get("world") or raw.get("world_file") or raw.get("world_name")
    world_file = _resolve_world_path(world_entry, config_dir=config_dir)

    robots: List[RobotScenario] = []
    for entry in raw.get("robots", []):
        if "preset" not in entry:
            raise ValueError("Robot entry must define a 'preset'")
        if "name" not in entry:
            raise ValueError("Robot entry must define a 'name'")

        overrides = _build_robot_overrides(entry)
        # Create robot specification from registry with RobotCfg
        spec = robot_registry.create(entry["preset"], entry["name"], overrides=overrides)
        robots.append(
            RobotScenario(
                name=entry["name"],
                preset=entry["preset"],
                pose=entry.get("pose", {}),
                spec=spec,
            )
        )

    return EnvironmentConfig(
        world_file=world_file,
        robots=robots,
        name=raw.get("name"),
        reward=raw.get("reward", {}) or {},
        termination=raw.get("termination", {}) or {},
        metadata=raw.get("metadata", {}) or {},
    )
