#!/usr/bin/env python3
"""Training entry-point that borrows unitree_rl_gym's logging structure."""
from __future__ import annotations

import argparse
import json
import os
import random
import shutil
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from torch.utils.tensorboard import SummaryWriter

from gazebo_rl_gym.envs.multi_robot_env import MultiRobotGazeboEnv
from gazebo_rl_gym.algo.ppo.ppo import PPO
from gazebo_rl_gym.utils.path_utils import ensure_dir, resolve_relative


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train PPO agents in Gazebo")
    parser.add_argument("--config", default=resolve_relative("config", "envs", "warehouse.yaml"),
                        help="YAML file describing the scenario")
    parser.add_argument("--experiment", default="gazebo_multi_robot",
                        help="Experiment folder name under the log root")
    parser.add_argument("--run-name", default="",
                        help="Optional run name suffix appended to the timestamp")
    parser.add_argument("--log-root", default=resolve_relative("logs"),
                        help="Root directory that stores tensorboard and checkpoints")
    parser.add_argument("--max-timesteps", type=int, default=int(3e5),
                        help="Total training timesteps")
    parser.add_argument("--episode-length", type=int, default=1000,
                        help="Maximum steps per episode")
    parser.add_argument("--save-interval", type=int, default=int(1e5),
                        help="Checkpoint interval in environment steps")
    parser.add_argument("--seed", type=int, default=1, help="Random seed for numpy and torch")
    parser.add_argument("--print-interval", type=int, default=200,
                        help="Console print interval in environment steps")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def prepare_logging(args: argparse.Namespace) -> tuple[Path, Path, SummaryWriter]:
    timestamp = datetime.now().strftime('%b%d_%H-%M-%S')
    suffix = f"_{args.run_name}" if args.run_name else ""
    log_dir = Path(args.log_root) / args.experiment / (timestamp + suffix)
    tb_dir = log_dir / "tb"
    ckpt_dir = log_dir / "checkpoints"
    ensure_dir(str(tb_dir))
    ensure_dir(str(ckpt_dir))
    writer = SummaryWriter(str(tb_dir))
    return log_dir, ckpt_dir, writer


def dump_run_metadata(log_dir: Path, args: argparse.Namespace) -> None:
    meta = {
        "config": os.path.abspath(args.config),
        "max_timesteps": args.max_timesteps,
        "episode_length": args.episode_length,
        "save_interval": args.save_interval,
        "seed": args.seed,
    }
    with open(log_dir / "run_meta.json", "w", encoding="utf-8") as handle:
        json.dump(meta, handle, indent=2)
    shutil.copy2(args.config, log_dir / Path(args.config).name)


def build_agents(env: MultiRobotGazeboEnv) -> dict[str, PPO]:
    gamma = 0.99
    eps_clip = 0.2
    lr_actor = 3e-4
    lr_critic = 1e-3
    action_std = 0.6
    action_std_decay_rate = 0.05
    min_action_std = 0.1
    K_epochs = 80

    agents: dict[str, PPO] = {}
    for name in env.robot_names:
        obs_dim = env.get_observation_size(name)
        action_dim = env.get_action_size(name)
        agents[name] = PPO(obs_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, action_std)
        agents[name].action_std_decay_rate = action_std_decay_rate
        agents[name].min_action_std = min_action_std
    return agents


def save_checkpoint(agents: dict[str, PPO], ckpt_dir: Path, env_name: str, step: int) -> None:
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    for name, agent in agents.items():
        checkpoint = ckpt_dir / f"{env_name}_{name}_step_{step}.pth"
        agent.save(str(checkpoint))


def maybe_decay_action_std(agents: dict[str, PPO], step: int, decay_freq: int) -> None:
    if decay_freq <= 0:
        return
    if step % decay_freq == 0:
        for agent in agents.values():
            agent.decay_action_std(agent.action_std_decay_rate, agent.min_action_std)


def train(args: argparse.Namespace) -> None:
    set_seed(args.seed)
    log_dir, ckpt_dir, writer = prepare_logging(args)
    dump_run_metadata(log_dir, args)
    print("=" * 50)
    print(f"Using configuration: {args.config}")
    env = MultiRobotGazeboEnv(config_path=args.config)
    agents = build_agents(env)

    env_name = "MultiRobotGazebo"
    update_timestep = args.episode_length * 4
    print_interval = args.print_interval
    action_std_decay_freq = int(2.5e5)

    start_time = datetime.now().replace(microsecond=0)
    print(f"Training started at {start_time} (GMT)")

    time_step = 0
    episode_index = 0

    try:
        while time_step < args.max_timesteps:
            state = env.reset()
            current_ep_reward = {name: 0.0 for name in env.robot_names}

            for _ in range(1, args.episode_length + 1):
                actions = {name: agents[name].select_action(state[name]) for name in env.robot_names}
                state, reward, done, _ = env.step(actions)

                for name in env.robot_names:
                    agents[name].buffer.rewards.append(reward[name])
                    agents[name].buffer.is_terminals.append(done[name])
                    current_ep_reward[name] += reward[name]

                time_step += 1

                # 记录每步的 reward 和 actions
                for name in env.robot_names:
                    writer.add_scalar(f"{name}/step_reward", reward[name], time_step)
                    action_vec = np.array(actions[name])
                    writer.add_histogram(f"{name}/action", action_vec, time_step)

                if time_step % update_timestep == 0:
                    for agent in agents.values():
                        agent.update()

                maybe_decay_action_std(agents, time_step, action_std_decay_freq)

                if time_step % args.save_interval == 0:
                    save_checkpoint(agents, ckpt_dir, env_name, time_step)
                    elapsed = datetime.now().replace(microsecond=0) - start_time
                    print(f"Checkpoint saved at step {time_step} (elapsed {elapsed})")

                if time_step % print_interval == 0:
                    rewards_str = ", ".join(f"{name}: {reward:.2f}" for name, reward in current_ep_reward.items())
                    print(f"Step {time_step} | Episode {episode_index+1} | Rewards -> {rewards_str}")

                if done.get('__all__', False):
                    break

                if time_step >= args.max_timesteps:
                    break

            # 记录每回合的奖励
            for name, ep_reward in current_ep_reward.items():
                writer.add_scalar(f"{name}/episode_reward", ep_reward, episode_index)

            episode_index += 1

    finally:
        env.close()
        writer.close()

        elapsed = datetime.now().replace(microsecond=0) - start_time
        print(f"Training finished after {elapsed}. Logs stored in {log_dir}")


if __name__ == "__main__":
    train(parse_args())
