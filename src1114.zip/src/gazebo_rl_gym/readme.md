# Gazebo RL Gym

融合 unitree_rl_gym、ros_motion_planning、rl_sar 的思路，构建可通过 YAML 灵活配置的多机器人 Gazebo 仿真训练框架。环境封装为 Gym 接口，默认集成 PPO 训练流程，并为每个机器人自动处理命名空间与话题区分。

## 代码结构
- config: 环境和机器人 YAML 配置，`config/robots/` 定义可复用的机器人预设（模型路径、动作范围、观测布局等），`config/envs/` 组合世界文件与机器人实例、奖励/终止参数
- launch: ROS 启动文件，负责装载世界、机器人和相关插件。
- models 与 meshes: Gazebo 使用的场景与网格资源。
- scripts/gazebo_rl_gym/envs: Gym 环境实现，`multi_robot_env.py` 提供多机器人封装，订阅激光与 p3d 里程计话题并计算观测、奖励、终止条件。
- scripts/gazebo_rl_gym/utils: 通用工具，例如路径解析、配置加载、日志目录管理。
- scripts/spawn_robots.py: 依据 YAML 在 Gazebo 中生成机器人、上传控制器、设置命名空间。
- scripts/train.py: 训练入口，解析命令行参数、构造环境、运行 PPO 训练并记录日志与模型。
- urdf: 机器人模型描述及 Gazebo 插件配置
- rviz 与 worlds: 可视化配置以及预置仿真场景。

## 模块功能
- 环境封装: `MultiRobotGazeboEnv` 通过 ROS 服务控制 Gazebo 重置与模型状态；依据机器人预设生成观测（位姿组件 + 激光）；奖励/终止条件从环境配置中读取，可按场景调整位移系数或高度阈值。
- 配置系统: `EnvironmentConfig` 和 `RobotConfig` 解析 YAML，通过 `config/robots/` 复用机器人预设（模型、动作范围、观测布局），并在 `config/envs/` 组合世界、实例化机器人及奖励/终止策略。
- 机器人生成: `spawn_robots.py` 加载 xacro、上传控制器、应用命名空间，保证多机器人运行互不干扰。
- 训练流程: `train.py` 负责 PPO 训练循环、经验采集、策略更新、日志记录及模型保存，目录结构与 unitree_rl_gym 对齐。
- 日志与路径: `path_utils.py` 提供 ROS 包内路径解析；`logging_utils.py`（若存在）集中管理日志目录、TensorBoard 输出。

## 使用说明概览
- 启动仿真: `roslaunch gazebo_rl_gym multi_robot.launch config_file:=<env_yaml>`，默认加载 `config/envs/warehouse.yaml`。
- 开始训练: `rosrun gazebo_rl_gym train.py --config config/envs/warehouse.yaml --experiment <name>`。
- 扩展环境: 在 `config/` 新增 YAML，选用或自定义机器人预设并组合到场景中；若模型未含 p3d 插件，请在对应 `.gazebo.xacro` 中添加 `libgazebo_ros_p3d.so`，确保位姿话题与 `pose_topic` 一致。

# TODO：
- 所有配置机器人obs和action和reward没有分离，都是一样的
- reset和step时：
    - Gazebo中基于ros的服务的异步模拟仿真，导致getObs的状态不一定是执行当前action后的，可能会动作状态错位，基于ros的收发是一种伪同步
    - Mujoco中不存在此问题，在step中以固定的仿真dt进行物理世界的步进，没有后台线程或异步更新。所以动作和状态对应。
- 兼容多机器人控制，继承gazebo_ros_controller分装的gazebo控制接口controller_interface::Controller<hardware_interface::EffortJointInterface>，实现自己的关节控制